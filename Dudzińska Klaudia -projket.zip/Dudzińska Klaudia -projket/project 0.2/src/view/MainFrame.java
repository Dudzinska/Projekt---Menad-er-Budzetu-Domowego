package view;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.Map;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("Budżet domowy");
        setMinimumSize(new Dimension(1200, 800));
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));

        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.LIGHT_GRAY);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        leftPanel.setMinimumSize(new Dimension(600, 800));
        leftPanel.setPreferredSize(new Dimension(600, 800));
        leftPanel.setAlignmentY(Component.TOP_ALIGNMENT);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.LIGHT_GRAY);
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        rightPanel.setPreferredSize(new Dimension(600, 800));

        String[] expenseCategories = { "Jedzenie", "Transport", "Mieszkanie", "Rozrywka", "Inne" };
        String[] incomeCategories = { "Pensja", "Premia", "Zwrot podatku", "Inne" };

        JPanel topLeftDiv = new JPanel();
        topLeftDiv.setBackground(Color.PINK);
        topLeftDiv.setLayout(new BoxLayout(topLeftDiv, BoxLayout.X_AXIS));

        JPanel expenseInputPanel = new JPanel();
        expenseInputPanel.setLayout(new GridLayout(4, 2, 10, 10));
        expenseInputPanel.setOpaque(false);

        JLabel expenseCategoryLabel = new JLabel("Kategoria:");
        JComboBox<String> expenseCategoryCombo = new JComboBox<>(expenseCategories);

        JLabel expenseDescLabel = new JLabel("Opis:");
        JTextField expenseDescField = new JTextField(10);

        JLabel expenseDateLabel = new JLabel("Data (YYYY-MM-DD):");
        JTextField expenseDateField = new JTextField(10);

        JLabel expenseAmountLabel = new JLabel("Kwota:");
        JTextField expenseAmountField = new JTextField(10);

        expenseInputPanel.add(expenseCategoryLabel);
        expenseInputPanel.add(expenseCategoryCombo);
        expenseInputPanel.add(expenseDescLabel);
        expenseInputPanel.add(expenseDescField);
        expenseInputPanel.add(expenseDateLabel);
        expenseInputPanel.add(expenseDateField);
        expenseInputPanel.add(expenseAmountLabel);
        expenseInputPanel.add(expenseAmountField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        JButton addExpenseButton = new JButton("Dodaj");
        buttonPanel.add(addExpenseButton);

        topLeftDiv.add(expenseInputPanel);
        topLeftDiv.add(Box.createHorizontalStrut(20));
        topLeftDiv.add(buttonPanel);

        JPanel middleLeftDiv = new JPanel();
        middleLeftDiv.setBackground(Color.ORANGE);
        middleLeftDiv.setLayout(new BoxLayout(middleLeftDiv, BoxLayout.X_AXIS));

        JPanel incomeInputPanel = new JPanel();
        incomeInputPanel.setLayout(new GridLayout(4, 2, 10, 10));
        incomeInputPanel.setOpaque(false);

        JLabel incomeCategoryLabel = new JLabel("Kategoria:");
        JComboBox<String> incomeCategoryCombo = new JComboBox<>(incomeCategories);

        JLabel incomeDescLabel = new JLabel("Opis:");
        JTextField incomeDescField = new JTextField(10);

        JLabel incomeDateLabel = new JLabel("Data (YYYY-MM-DD):");
        JTextField incomeDateField = new JTextField(10);

        JLabel incomeAmountLabel = new JLabel("Pensja:");
        JTextField incomeAmountField = new JTextField(10);

        incomeInputPanel.add(incomeCategoryLabel);
        incomeInputPanel.add(incomeCategoryCombo);
        incomeInputPanel.add(incomeDescLabel);
        incomeInputPanel.add(incomeDescField);
        incomeInputPanel.add(incomeDateLabel);
        incomeInputPanel.add(incomeDateField);
        incomeInputPanel.add(incomeAmountLabel);
        incomeInputPanel.add(incomeAmountField);

        JPanel incomeButtonPanel = new JPanel();
        incomeButtonPanel.setOpaque(false);
        JButton addIncomeButton = new JButton("Dodaj");
        incomeButtonPanel.add(addIncomeButton);

        middleLeftDiv.add(incomeInputPanel);
        middleLeftDiv.add(Box.createHorizontalStrut(20));
        middleLeftDiv.add(incomeButtonPanel);

        BudgetPanel budgetPanel = new BudgetPanel();
        JPanel topRightDiv = budgetPanel;

        Map<String, Double> expenseData = new HashMap<>();

        Map<String, Double> transactionData = new LinkedHashMap<>();

        GraphPanel graphPanel = new GraphPanel(expenseData, transactionData);

        JPanel bottomRightDiv = new JPanel();
        bottomRightDiv.setLayout(new BorderLayout());
        bottomRightDiv.add(graphPanel, BorderLayout.CENTER);

        TransactionsPanel transactionsPanel = new TransactionsPanel(budgetPanel, graphPanel);
        JPanel bottomLeftDiv = transactionsPanel;
        bottomLeftDiv.setBackground(Color.CYAN);
        bottomLeftDiv.setMaximumSize(new Dimension(600, Integer.MAX_VALUE));
        bottomLeftDiv.setPreferredSize(new Dimension(600, 500));
        bottomLeftDiv.setMinimumSize(new Dimension(600, 200));

        leftPanel.add(topLeftDiv);
        leftPanel.add(middleLeftDiv);
        leftPanel.add(bottomLeftDiv);
        leftPanel.add(Box.createVerticalGlue());

        rightPanel.add(topRightDiv);
        rightPanel.add(bottomRightDiv);

        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        setContentPane(mainPanel);

        
        addExpenseButton.addActionListener(e -> {
            String category = expenseCategoryCombo.getSelectedItem().toString();
            String desc = expenseDescField.getText();
            String date = expenseDateField.getText();
            String amount = expenseAmountField.getText();

            if (!amount.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "Kwota może zawierać tylko cyfry 0-9!", "Błąd",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Data musi być w formacie YYYY-MM-DD!", "Błąd",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            transactionsPanel.addExpense(category, desc, date, amount);
            transactionsPanel.refreshTable();
            expenseCategoryCombo.setSelectedIndex(0);
            expenseDescField.setText("");
            expenseDateField.setText("");
            expenseAmountField.setText("");

            budgetPanel.setTotal(transactionsPanel.getTotalAmount());
            graphPanel.updateData(transactionsPanel.getExpenseSummary(), transactionsPanel.getTransactionSummary());
        });

        addIncomeButton.addActionListener(e -> {
            String category = incomeCategoryCombo.getSelectedItem().toString();
            String desc = incomeDescField.getText();
            String date = incomeDateField.getText();
            String amount = incomeAmountField.getText();

            if (!amount.matches("\\d+")) {
                JOptionPane.showMessageDialog(this, "Kwota może zawierać tylko cyfry 0-9!", "Błąd",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Data musi być w formacie YYYY-MM-DD!", "Błąd",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            transactionsPanel.addIncome(category, desc, date, amount);
            transactionsPanel.refreshTable();
            incomeCategoryCombo.setSelectedIndex(0);
            incomeDescField.setText("");
            incomeDateField.setText("");
            incomeAmountField.setText("");

            budgetPanel.setTotal(transactionsPanel.getTotalAmount());
            graphPanel.updateData(transactionsPanel.getExpenseSummary(), transactionsPanel.getTransactionSummary());
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}