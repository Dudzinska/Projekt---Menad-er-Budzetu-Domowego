package view;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class TransactionsPanel extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;
    private BudgetPanel budgetPanel;
    private GraphPanel graphPanel;

    public TransactionsPanel(BudgetPanel budgetPanel, GraphPanel graphPanel) {
        this.budgetPanel = budgetPanel;
        this.graphPanel = graphPanel;
        setLayout(new BorderLayout());

        String[] columns = { "Kategoria", "Opis", "Data", "Kwota", " " };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
               
                return column == 4;
            }
        };
        table = new JTable(tableModel);

        table.getColumn(" ").setCellRenderer(new ButtonRenderer());
        table.getColumn(" ").setCellEditor(new ButtonEditor(new JCheckBox()));
        table.getColumn(" ").setMaxWidth(50);
        table.getColumn(" ").setPreferredWidth(50);

        add(new JLabel("Wydatki i zarobki:"), BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    
    public void addExpense(String category, String desc, String date, String amount) {
        tableModel.addRow(new Object[] { category, desc, date, "-" + amount, "Usuń" });
    }

    public void addIncome(String category, String desc, String date, String amount) {
        tableModel.addRow(new Object[] { category, desc, date, amount, "Usuń" });
    }

   
    public void refreshTable() {
        table.repaint();
        table.revalidate();
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setText("X");
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton("Usuń");
            button.addActionListener(e -> {
                if (selectedRow >= 0) {
                    fireEditingStopped();
                    tableModel.removeRow(selectedRow);
                    budgetPanel.setTotal(getTotalAmount());
                    graphPanel.updateData(getExpenseSummary(), getTransactionSummary());
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            selectedRow = row;
            return button;
        }
    }

    public double getTotalAmount() {
        double sum = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            try {
                sum += Double.parseDouble(tableModel.getValueAt(i, 3).toString());
            } catch (NumberFormatException e) {
                
            }
        }
        return sum;
    }

   
    public Map<String, Double> getExpenseSummary() {
        Map<String, Double> summary = new HashMap<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String category = tableModel.getValueAt(i, 0).toString();
            double amount = 0.0;
            try {
                amount = Double.parseDouble(tableModel.getValueAt(i, 3).toString());
            } catch (NumberFormatException e) {
                continue;
            }
          
            if (amount < 0) {
                summary.put(category, summary.getOrDefault(category, 0.0) + Math.abs(amount));
            }
        }
        return summary;
    }

   
    public Map<String, Double> getTransactionSummary() {
        Map<String, Double> summary = new LinkedHashMap<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String date = tableModel.getValueAt(i, 2).toString();
            double amount = 0.0;
            try {
                amount = Double.parseDouble(tableModel.getValueAt(i, 3).toString());
            } catch (NumberFormatException e) {
                continue;
            }
            summary.put(date, summary.getOrDefault(date, 0.0) + amount);
        }
        return summary;
    }
}