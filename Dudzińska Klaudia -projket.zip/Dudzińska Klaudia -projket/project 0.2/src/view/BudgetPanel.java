package view;

import javax.swing.*;
import java.awt.*;

public class BudgetPanel extends JPanel {
    private JLabel totalLabel;
    private double total = 0.0;

    public BudgetPanel() {
        setBackground(new Color(220, 255, 220));
        setPreferredSize(new Dimension(600, 100));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        setLayout(new FlowLayout(FlowLayout.LEFT));
        add(new JLabel("Budżet domowy:"));
        totalLabel = new JLabel("0.00 zł");
        add(totalLabel);
    }

    public void setTotal(double total) {
        this.total = total;
        totalLabel.setText(String.format("%.2f zł", total));
    }

    public double getTotal() {
        return total;
    }
}
