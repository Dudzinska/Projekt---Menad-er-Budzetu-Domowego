package view;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class GraphPanel extends JPanel {
    private ChartPanel pieChartPanel;
    private ChartPanel barChartPanel;

    public GraphPanel(Map<String, Double> expenseData, Map<String, Double> transactionData) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(600, 300));
        createCharts(expenseData, transactionData);
    }

    public void updateData(Map<String, Double> expenseData, Map<String, Double> transactionData) {
        removeAll();
        createCharts(expenseData, transactionData);
        revalidate();
        repaint();
    }

    private void createCharts(Map<String, Double> expenseData, Map<String, Double> transactionData) {
       
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        for (Map.Entry<String, Double> entry : expenseData.entrySet()) {
            pieDataset.setValue(entry.getKey(), entry.getValue());
        }
        JFreeChart pieChart = ChartFactory.createPieChart(
                "Wydatki wg kategorii",
                pieDataset,
                false,
                true,
                false);
        pieChartPanel = new ChartPanel(pieChart);

        DefaultCategoryDataset barDataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Double> entry : transactionData.entrySet()) {
            barDataset.addValue(entry.getValue(), "Kwota", entry.getKey());
        }
        JFreeChart barChart = ChartFactory.createBarChart(
                "Transakcje w czasie",
                "Data",
                "Kwota",
                barDataset,
                org.jfree.chart.plot.PlotOrientation.VERTICAL,
                false, 
                true,
                false);
                
        barChartPanel = new ChartPanel(barChart);

        add(pieChartPanel);
        add(barChartPanel);
    }

}
